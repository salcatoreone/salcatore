import GTALanding from "../gta-landing"

export default function Page() {
  return <GTALanding />
}
